```js
import {JSONModel} from 'react-3d-viewer'

render(){
  return(
    <div>
      <JSONModel src="./src/lib/model/kapool.js"  />
    </div>
  )
}
```